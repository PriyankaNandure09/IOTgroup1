package com.psl.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.format.datetime.DateFormatter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.psl.Entity.Product;

public class ProductDAOImpl implements IProductDAO{

private JdbcTemplate jt;
	
	
	public JdbcTemplate getJt() {
		return jt;
	}


	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}


	public Product display(int productId) {
		System.out.println("Inside DAOIMPL");

     return jt.queryForObject("select * from product where productId="+productId,new RowMapper<Product>(){

			public Product mapRow(ResultSet rs, int arg1) throws SQLException {
				
				Product p=new Product();
				p.setProductId((Integer)rs.getInt("productId"));
				p.setProductName((String)rs.getString("productName"));
				p.setEmptyDateTime((String)rs.getString("emptyDate_time"));
				p.setStatus((Integer)rs.getInt("status"));
				p.setLocation((String)rs.getString("location"));
				p.setCount((Integer)rs.getInt("count"));
				return p;
			}
			
		});
	}


	
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		
		
			
		String sql="insert into product values("+p.getProductId()+",'"+p.getProductName()+"','"+p.getEmptyDateTime()+"'," +p.getStatus()+ " ,'"+p.getLocation()+"','"+p.getCount()+"')";
		System.out.println("updated  "+sql);
		jt.update(sql);
		
	}



	public void updateProduct(Product p) {

		
		String sql="update product set emptyDate_time ='"+p.getEmptyDateTime()+"', status='"+p.getStatus()+"' where productId="+p.getProductId();
		System.out.println("updated  "+sql);
		jt.update(sql);
		
	}


	public List<Product> displayAll() {
		
		String sql = "select * from product";

		List<Product> products = new ArrayList<Product>();

		List<Map<String, Object>> rows = getJt().queryForList(sql);
		for (Map row : rows) {
			Product p=new Product();
			p.setProductId((Integer)row.get("productId"));
			p.setProductName((String)row.get("productName"));
			p.setEmptyDateTime((String)row.get("emptyDate_time"));
			p.setStatus((Integer)row.get("status"));
			p.setLocation((String)row.get("location"));
			p.setCount((Integer)row.get("count"));
			products.add(p);
			
			System.out.println(p);
		}

		System.out.println(products);
		return products;
	}


}
