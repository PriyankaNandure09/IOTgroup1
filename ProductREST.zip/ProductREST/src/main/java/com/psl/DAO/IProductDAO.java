package com.psl.DAO;

import java.util.List;

import com.psl.Entity.Product;

public interface IProductDAO {

	public Product display(int productId);
	public List<Product> displayAll();
	public void addProduct(Product p);
	public void updateProduct(Product p);
}
