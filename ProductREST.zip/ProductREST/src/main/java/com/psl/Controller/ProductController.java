package com.psl.Controller;

import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.portlet.ModelAndView;

import com.psl.Entity.Product;
import com.psl.Service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	@RequestMapping(value="/Product/{productId}", method=RequestMethod.GET)
	public @ResponseBody Product getProduct(@PathVariable("productId") int productId){
		
		System.out.println("Inside Controller Index page..");
	
		Product p=service.display(productId);
		
		System.out.println(p);
		return p;
	}

	
	@RequestMapping(value="/Product", method=RequestMethod.GET)
	public @ResponseBody List<Product> getAllProducts(){
		
		System.out.println("Inside Controller Index page..");
	
		
		List<Product> list=service.displayAll();
		
		System.out.println(list);
		return list;
	}
	
	
	@RequestMapping(value = "/Product",method = RequestMethod.POST)
	public  @ResponseBody Product  addProduct(@RequestBody Product p)
	{
		service.addProduct(p);
		System.out.println("Product added ..");
		return p;
		
	}
	
	@RequestMapping(value="/Product",method = RequestMethod.PUT)
	public @ResponseBody Product updateProduct(@RequestBody Product p) {
		
	service.updateProduct(p);
		
	
	/*
		GMailSender gs=new GMailSender("technothon2k17", "1234@pass");
		try {
			gs.sendMail("Status of product in Store", "The status of Product with Product Id: "+p.getProductId()+" has status: "+p.getStatus()+" on date  "+p.getEmptyDateTime(), "technothon2k17@gmail.com", "technothon2k17@gmail.com");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         final String USERNAME = "9049373985";//REQUIRED
        final String PASSWORD = "M9863A";//REQUIRED
        final String ACTION = "/smstoss.action";//REQUIRED : In order to understand ACTION value please read the blog
        Way2SMS sms = new Way2SMS();
        String phoneNumber = "9049373985";
        String message = "The status of Product with Product Id: "+p.getProductId()+" has status: "+p.getStatus()+" on date  "+p.getEmptyDateTime();

        String cookie = sms.loginWay2SMS(USERNAME, PASSWORD);
        String textMessage = message.toString();
        String strPhoneNumber = phoneNumber.toString();
        String arrPhoneNUmber[] = strPhoneNumber.split(";");
        for (int i = 0; i < arrPhoneNUmber.length; i++)
        {
            sms.sendSMS(arrPhoneNUmber[i], textMessage);
        }

        sms.logoutWay2SMS();
	*/
		System.out.println("updated");
		return p;
	}
	
	
	
	
	@RequestMapping(value="/home1")
	public String showPage11(){
		
		
		return "home1";
	}
	
	
	

	

}
