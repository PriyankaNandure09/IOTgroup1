package com.psl.Service;

import java.util.ArrayList;
import java.util.List;



import com.psl.DAO.IProductDAO;
import com.psl.Entity.Product;

public class ProductService {

	private IProductDAO dao;

	public IProductDAO getDao() {
		return dao;
	}

	public void setDao(IProductDAO dao) {
		this.dao = dao;
	}
	
	public Product display(int pin) {
	Product p =	dao.display(pin);
		return p;
	}
	
	public void addProduct(Product p) {
		dao.addProduct(p);
	}


	
	public void updateProduct(Product p) {
		dao.updateProduct(p);
	}
	
	public List<Product> displayAll() {
	

		List<Product> l=new ArrayList<Product>();
		l=dao.displayAll();
		return l;
		
	}
}
