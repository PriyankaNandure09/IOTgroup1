package com.psl.Entity;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="product")
public class Product {

	private int productId;
	private String productName;
	private String emptyDateTime;
	private int status;
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	private String location;
	private int count;
	
	
	
	
	
	
	public Product() {
		super();
	}
	public Product(int productId, String productName, String emptyDateTime,
			int isEmpty, String location, int count) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.emptyDateTime = emptyDateTime;
		this.status = isEmpty;
		this.location = location;
		this.count = count;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getEmptyDateTime() {
		return emptyDateTime;
	}
	public void setEmptyDateTime(String emptyDateTime) {
		this.emptyDateTime = emptyDateTime;
	}
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", emptyDateTime=" + emptyDateTime
				+ ", isEmpty=" + status + ", location=" + location
				+ ", count=" + count + "]";
	}
	
	
	
	
	
	
}
